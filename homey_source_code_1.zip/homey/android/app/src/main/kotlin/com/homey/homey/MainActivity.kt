package com.homey.homey

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
