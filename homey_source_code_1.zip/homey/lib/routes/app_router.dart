import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:homey/features/auth/data/auth_repository.dart';
import 'package:homey/features/auth/presentation/screens/login_screen_controller.dart';
import 'package:homey/features/auth/presentation/screens/register_screen_controller.dart';
import 'package:homey/features/auth/presentation/screens/role_selection_screen_controller.dart';
import 'package:homey/features/customer/presentation/screens/customer_home_screen.dart';
import 'package:homey/features/cook/presentation/screens/cook_home_screen.dart';
import 'package:homey/features/admin/presentation/screens/admin_home_screen.dart';
import 'package:homey/features/auth/presentation/screens/splash_screen.dart';

final appRouterProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateChangesProvider);
  
  return GoRouter(
    initialLocation: '/',
    redirect: (context, state) {
      final isLoggedIn = authState.value != null;
      final isGoingToAuth = state.location == '/login' || 
                           state.location == '/register' || 
                           state.location == '/';
      
      // If not logged in and not going to auth, redirect to login
      if (!isLoggedIn && !isGoingToAuth) {
        return '/login';
      }
      
      // If logged in and going to auth, redirect to role selection
      if (isLoggedIn && isGoingToAuth && state.location != '/role-selection') {
        return '/role-selection';
      }
      
      return null;
    },
    routes: [
      GoRoute(
        path: '/',
        builder: (context, state) => const SplashScreen(),
      ),
      GoRoute(
        path: '/login',
        builder: (context, state) => const LoginScreenController(),
      ),
      GoRoute(
        path: '/register',
        builder: (context, state) => const RegisterScreenController(),
      ),
      GoRoute(
        path: '/role-selection',
        builder: (context, state) => const RoleSelectionScreenController(),
      ),
      GoRoute(
        path: '/customer',
        builder: (context, state) => const CustomerHomeScreen(),
      ),
      GoRoute(
        path: '/cook',
        builder: (context, state) => const CookHomeScreen(),
      ),
      GoRoute(
        path: '/admin',
        builder: (context, state) => const AdminHomeScreen(),
      ),
    ],
  );
});
