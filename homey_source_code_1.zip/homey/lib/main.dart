import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:homey/app/app.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Firebase with default options for now
  // In a production app, we would use proper Firebase configuration
  try {
    await Firebase.initializeApp();
    print('Firebase initialized successfully');
  } catch (e) {
    print('Failed to initialize Firebase: $e');
    // For MVP, we'll continue even if Firebase fails to initialize
    // This allows us to demonstrate the UI without requiring Firebase setup
  }
  
  runApp(
    const ProviderScope(
      child: HomeyApp(),
    ),
  );
}
