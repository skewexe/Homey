import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

// Firebase Firestore instance provider
final firestoreProvider = Provider<FirebaseFirestore>((ref) {
  return FirebaseFirestore.instance;
});

// User collection reference provider
final userCollectionProvider = Provider<CollectionReference>((ref) {
  return ref.watch(firestoreProvider).collection('users');
});

// Food items collection reference provider
final foodItemsCollectionProvider = Provider<CollectionReference>((ref) {
  return ref.watch(firestoreProvider).collection('foodItems');
});

// Orders collection reference provider
final ordersCollectionProvider = Provider<CollectionReference>((ref) {
  return ref.watch(firestoreProvider).collection('orders');
});

// Reviews collection reference provider
final reviewsCollectionProvider = Provider<CollectionReference>((ref) {
  return ref.watch(firestoreProvider).collection('reviews');
});

class DatabaseService {
  final FirebaseFirestore _firestore;

  DatabaseService(this._firestore);

  // User methods
  Future<void> createUserProfile(String uid, Map<String, dynamic> userData) async {
    try {
      await _firestore.collection('users').doc(uid).set(userData);
    } catch (e) {
      rethrow;
    }
  }

  Future<Map<String, dynamic>?> getUserProfile(String uid) async {
    try {
      final doc = await _firestore.collection('users').doc(uid).get();
      return doc.data();
    } catch (e) {
      rethrow;
    }
  }

  Future<void> updateUserProfile(String uid, Map<String, dynamic> userData) async {
    try {
      await _firestore.collection('users').doc(uid).update(userData);
    } catch (e) {
      rethrow;
    }
  }

  // Food item methods
  Future<String> createFoodItem(Map<String, dynamic> foodItemData) async {
    try {
      final docRef = await _firestore.collection('foodItems').add(foodItemData);
      return docRef.id;
    } catch (e) {
      rethrow;
    }
  }

  Future<void> updateFoodItem(String id, Map<String, dynamic> foodItemData) async {
    try {
      await _firestore.collection('foodItems').doc(id).update(foodItemData);
    } catch (e) {
      rethrow;
    }
  }

  Future<void> deleteFoodItem(String id) async {
    try {
      await _firestore.collection('foodItems').doc(id).delete();
    } catch (e) {
      rethrow;
    }
  }

  Stream<QuerySnapshot> getFoodItemsByCook(String cookId) {
    return _firestore
        .collection('foodItems')
        .where('cookId', isEqualTo: cookId)
        .snapshots();
  }

  // Order methods
  Future<String> createOrder(Map<String, dynamic> orderData) async {
    try {
      final docRef = await _firestore.collection('orders').add(orderData);
      return docRef.id;
    } catch (e) {
      rethrow;
    }
  }

  Future<void> updateOrderStatus(String id, String status) async {
    try {
      await _firestore.collection('orders').doc(id).update({
        'orderStatus': status,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      rethrow;
    }
  }

  Stream<QuerySnapshot> getCustomerOrders(String customerId) {
    return _firestore
        .collection('orders')
        .where('customerId', isEqualTo: customerId)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  Stream<QuerySnapshot> getCookOrders(String cookId) {
    return _firestore
        .collection('orders')
        .where('cookId', isEqualTo: cookId)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  // Review methods
  Future<String> createReview(Map<String, dynamic> reviewData) async {
    try {
      final docRef = await _firestore.collection('reviews').add(reviewData);
      return docRef.id;
    } catch (e) {
      rethrow;
    }
  }

  Stream<QuerySnapshot> getCookReviews(String cookId) {
    return _firestore
        .collection('reviews')
        .where('cookId', isEqualTo: cookId)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }
}

// Database service provider
final databaseServiceProvider = Provider<DatabaseService>((ref) {
  return DatabaseService(ref.watch(firestoreProvider));
});
